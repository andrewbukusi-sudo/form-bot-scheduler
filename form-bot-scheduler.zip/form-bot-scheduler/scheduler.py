import requests, time, random
from datetime import datetime

SUBMIT_URL = "https://YOUR-SERVICE.onrender.com/submit"  # replace with your Render URL
TOTAL_SUBMISSIONS = 80
SECS_24HRS = 24 * 60 * 60

delays = sorted(random.sample(range(SECS_24HRS), TOTAL_SUBMISSIONS))
print("Scheduler started")

prev = 0
for i, t in enumerate(delays, 1):
    wait = t - prev
    prev = t
    print(f"[{datetime.now()}] Waiting {wait}s before submission {i}")
    time.sleep(wait)
    try:
        resp = requests.get(SUBMIT_URL)
        print(f"[{datetime.now()}] {resp.text}")
    except Exception as e:
        print(f"[{datetime.now()}] Error: {e}")
